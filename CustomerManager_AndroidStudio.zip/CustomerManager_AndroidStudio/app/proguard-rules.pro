# Keep JavaScript bridge methods used by WebView
-keepclassmembers class com.customermanager.app.MainActivity$AndroidDownloader {
    @android.webkit.JavascriptInterface <methods>;
}
