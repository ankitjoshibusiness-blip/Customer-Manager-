Customer Manager - Android Studio Project
=========================================

Aa ZIP ma Android Studio mate complete project ane app no badho j source code chhe:

Folder Structure:
- settings.gradle.kts, build.gradle.kts, gradle/  -> Android Studio Gradle setup
- app/build.gradle.kts                            -> Android app build config (SDK 35, Kotlin 2.0.21)
- app/src/main/AndroidManifest.xml                -> Camera, GPS, Storage permissions
- app/src/main/java/com/customermanager/app/MainActivity.kt -> Kotlin Android entry point (WebViewAssetLoader + Camera + File Picker + Native Downloads)
- app/src/main/assets/                            -> Ready-to-run compiled Customer Manager app (Offline!)
- web-source/                                     -> Complete React + TypeScript source code (src/, package.json, vite.config.ts, etc.)

Android Studio ma open & APK build karvani rit:
1. Aa ZIP file ne Extract (Unzip) karo.
2. Android Studio kholo -> File -> Open -> "CustomerManager_AndroidStudio" folder select karo.
3. Gradle Sync pooru thava do (internet chalu rakhjo first sync mate).
4. APK banavva mate: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
   APK file tamne "app/build/outputs/apk/debug/app-debug.apk" ma malse.

UI / Features ma ferfar karva mate:
1. "web-source/" folder ma tamari files (src/App.tsx, src/components/..., src/services/...) edit karo.
2. Terminal ma "web-source" folder ma run karo:
      npm install
      npm run build
3. "web-source/dist/" ni badhi files copy karine "app/src/main/assets/" ma replace kari do.
4. Android Studio mathi fari APK build kari lo!
