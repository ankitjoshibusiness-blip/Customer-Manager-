import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Camera,
  Check,
  Crop,
  Flashlight,
  ImagePlus,
  RefreshCw,
  RotateCcw,
  RotateCw,
  ScanLine,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import {
  applyScannerFilter,
  detectDocumentQuad,
  FULL_IMAGE_QUAD,
  FULL_QUAD,
  warpPerspectiveQuad,
  type DocumentQuad,
  type ScannerFilterType,
} from '../services/documentScannerEngine';
import { createPdfFromImageBlobs } from '../services/pdfExport';

interface ScannedPage {
  id: string;
  sourceBlob: Blob;
  previewUrl: string;
  quad: DocumentQuad;
  rotation: 0 | 90 | 180 | 270;
  filter: ScannerFilterType;
}

interface DocumentScannerModalProps {
  docTitle: string;
  onClose: () => void;
  onSavePdf: (pdfBlob: Blob, pageCount: number) => Promise<void>;
}

const FILTER_OPTIONS: Array<{ id: ScannerFilterType; label: string }> = [
  { id: 'clean', label: 'Auto Clean' },
  { id: 'color', label: 'Color' },
  { id: 'bw', label: 'B&W' },
  { id: 'grayscale', label: 'Grayscale' },
  { id: 'original', label: 'Original' },
];

function quadMovement(a: DocumentQuad, b: DocumentQuad): number {
  let maxDist = 0;
  for (let i = 0; i < 4; i++) {
    const d = Math.hypot(a[i].x - b[i].x, a[i].y - b[i].y);
    if (d > maxDist) maxDist = d;
  }
  return maxDist;
}

function lerpQuad(prev: DocumentQuad, next: DocumentQuad, alpha = 0.35): DocumentQuad {
  return [
    { x: prev[0].x + (next[0].x - prev[0].x) * alpha, y: prev[0].y + (next[0].y - prev[0].y) * alpha },
    { x: prev[1].x + (next[1].x - prev[1].x) * alpha, y: prev[1].y + (next[1].y - prev[1].y) * alpha },
    { x: prev[2].x + (next[2].x - prev[2].x) * alpha, y: prev[2].y + (next[2].y - prev[2].y) * alpha },
    { x: prev[3].x + (next[3].x - prev[3].x) * alpha, y: prev[3].y + (next[3].y - prev[3].y) * alpha },
  ];
}

function loadImgFromUrl(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = url;
  });
}

export const DocumentScannerModal: React.FC<DocumentScannerModalProps> = ({
  docTitle,
  onClose,
  onSavePdf,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement | null>(null);
  const pagesRef = useRef<ScannedPage[]>([]);
  const cropBoxRef = useRef<HTMLDivElement | null>(null);
  const cropImgRef = useRef<HTMLImageElement | null>(null);
  const loupeCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Live detection & auto-capture refs
  const smoothedQuadRef = useRef<DocumentQuad | null>(null);
  const missCountRef = useRef<number>(0);
  const steadySinceRef = useRef<number | null>(null);
  const autoCooldownRef = useRef<number>(0);

  const [mode, setMode] = useState<'camera' | 'review'>('camera');
  const [autoCapture, setAutoCapture] = useState(true);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [torchSupported, setTorchSupported] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [cameraReady, setCameraReady] = useState(false);
  const [scanStatus, setScanStatus] = useState('Position document in frame');
  const [captureFlash, setCaptureFlash] = useState(false);

  const [pages, setPages] = useState<ScannedPage[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [retakingIndex, setRetakingIndex] = useState<number | null>(null);

  // Review editor states
  const [cropEditing, setCropEditing] = useState(false);
  const [draftQuad, setDraftQuad] = useState<DocumentQuad>(FULL_QUAD);
  const [draggingCorner, setDraggingCorner] = useState<number | null>(null);
  const [showFiltersBar, setShowFiltersBar] = useState(true);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');

  useEffect(() => {
    pagesRef.current = pages;
  }, [pages]);

  useEffect(() => {
    return () => {
      pagesRef.current.forEach((p) => URL.revokeObjectURL(p.previewUrl));
    };
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraReady(false);
    setTorchOn(false);
    setTorchSupported(false);
  }, []);

  const startCamera = useCallback(async () => {
    stopCamera();
    setCameraError('');
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError('Live camera is unavailable in this browser. Pick photos or use Device Camera below.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1920 },
          height: { ideal: 1440 },
        },
        audio: false,
      });
      streamRef.current = stream;
      const track = stream.getVideoTracks()[0];
      if (track && typeof track.getCapabilities === 'function') {
        const caps = track.getCapabilities() as MediaTrackCapabilities & { torch?: boolean };
        setTorchSupported(Boolean(caps.torch));
      }
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
        setCameraReady(true);
      }
    } catch (err) {
      setCameraError(
        err instanceof Error
          ? err.message
          : 'Camera permission denied or no camera detected.'
      );
    }
  }, [facingMode, stopCamera]);

  useEffect(() => {
    if (mode === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [mode, startCamera, stopCamera]);

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track || !torchSupported) return;
    const next = !torchOn;
    try {
      await track.applyConstraints({
        advanced: [{ torch: next } as MediaTrackConstraintSet],
      });
      setTorchOn(next);
    } catch {
      // torch unsupported by device hardware
    }
  };

  const captureFromVideo = useCallback(
    async (detectedQuad: DocumentQuad | null) => {
      const video = videoRef.current;
      if (!video || !video.videoWidth || !video.videoHeight) return;

      setCaptureFlash(true);
      window.setTimeout(() => setCaptureFlash(false), 180);

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      const blob = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.94)
      );
      if (!blob) return;

      const previewUrl = URL.createObjectURL(blob);
      const quad = detectedQuad ?? detectDocumentQuad(canvas) ?? FULL_IMAGE_QUAD;

      if (retakingIndex !== null) {
        setPages((prev) =>
          prev.map((p, idx) => {
            if (idx !== retakingIndex) return p;
            URL.revokeObjectURL(p.previewUrl);
            return {
              ...p,
              sourceBlob: blob,
              previewUrl,
              quad,
              rotation: 0,
            };
          })
        );
        setActiveIndex(retakingIndex);
        setRetakingIndex(null);
        setMode('review');
      } else {
        const nextPage: ScannedPage = {
          id: `scan_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          sourceBlob: blob,
          previewUrl,
          quad,
          rotation: 0,
          filter: 'clean',
        };
        setPages((prev) => {
          const next = [...prev, nextPage];
          setActiveIndex(next.length - 1);
          return next;
        });
      }
    },
    [retakingIndex]
  );

  // Real-time document boundary overlay + Google Drive Auto-Capture loop
  useEffect(() => {
    if (mode !== 'camera' || !cameraReady) return;
    let cancelled = false;
    let rafId = 0;
    let lastDetectAt = 0;

    const tick = (now: number) => {
      if (cancelled) return;
      const video = videoRef.current;
      const overlay = overlayCanvasRef.current;

      if (video && overlay && video.videoWidth > 0 && video.videoHeight > 0) {
        const rect = overlay.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          if (overlay.width !== Math.round(rect.width) || overlay.height !== Math.round(rect.height)) {
            overlay.width = Math.round(rect.width);
            overlay.height = Math.round(rect.height);
          }

          // Compute exact displayed video rectangle inside object-contain viewport
          const vidRatio = video.videoWidth / video.videoHeight;
          const boxRatio = overlay.width / overlay.height;
          let drawW = overlay.width;
          let drawH = overlay.height;
          let offX = 0;
          let offY = 0;
          if (vidRatio > boxRatio) {
            drawH = overlay.width / vidRatio;
            offY = (overlay.height - drawH) / 2;
          } else {
            drawW = overlay.height * vidRatio;
            offX = (overlay.width - drawW) / 2;
          }

          if (now - lastDetectAt > 140) {
            lastDetectAt = now;
            const rawQuad = detectDocumentQuad(video);
            if (rawQuad) {
              missCountRef.current = 0;
              const prev = smoothedQuadRef.current;
              const next = prev ? lerpQuad(prev, rawQuad, 0.42) : rawQuad;
              const moved = prev ? quadMovement(prev, rawQuad) : 1;
              smoothedQuadRef.current = next;

              if (autoCapture && now > autoCooldownRef.current) {
                if (moved < 0.04) {
                  if (steadySinceRef.current === null) {
                    steadySinceRef.current = now;
                  }
                  const heldMs = now - steadySinceRef.current;
                  if (heldMs >= 1000) {
                    autoCooldownRef.current = now + 2600;
                    steadySinceRef.current = null;
                    setScanStatus('Captured! Scan next page or tap Review');
                    captureFromVideo(next);
                  } else {
                    setScanStatus('Document locked · Hold steady…');
                  }
                } else {
                  steadySinceRef.current = now;
                  setScanStatus('Document detected · Hold steady');
                }
              } else if (now > autoCooldownRef.current) {
                setScanStatus(autoCapture ? 'Document detected' : 'Document detected · Tap shutter');
              }
            } else {
              missCountRef.current += 1;
              if (missCountRef.current > 3) {
                smoothedQuadRef.current = null;
                steadySinceRef.current = null;
                if (now > autoCooldownRef.current) {
                  setScanStatus(
                    autoCapture ? 'Point camera at document…' : 'Manual mode · Tap shutter to capture'
                  );
                }
              }
            }
          }

          // Draw live Google Drive-style blue quadrilateral overlay (or subtle corner reticle while searching)
          const ctx = overlay.getContext('2d');
          if (ctx) {
            ctx.clearRect(0, 0, overlay.width, overlay.height);
            const q = smoothedQuadRef.current;
            if (q) {
              const pts = q.map((p) => ({
                x: offX + p.x * drawW,
                y: offY + p.y * drawH,
              }));

              ctx.save();
              ctx.beginPath();
              ctx.moveTo(pts[0].x, pts[0].y);
              ctx.lineTo(pts[1].x, pts[1].y);
              ctx.lineTo(pts[2].x, pts[2].y);
              ctx.lineTo(pts[3].x, pts[3].y);
              ctx.closePath();
              ctx.fillStyle = 'rgba(66, 133, 244, 0.16)';
              ctx.fill();
              ctx.lineWidth = 3;
              ctx.strokeStyle = '#8AB4F8';
              ctx.stroke();

              // Glowing blue corner dots
              for (const pt of pts) {
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
                ctx.fillStyle = '#4285F4';
                ctx.fill();
                ctx.lineWidth = 2;
                ctx.strokeStyle = '#FFFFFF';
                ctx.stroke();
              }
              ctx.restore();
            } else {
              // Faint viewfinder corner brackets while looking for document edges
              const mX = offX + drawW * 0.1;
              const mY = offY + drawH * 0.1;
              const rX = offX + drawW * 0.9;
              const rY = offY + drawH * 0.9;
              const arm = Math.min(drawW, drawH) * 0.065;
              ctx.save();
              ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
              ctx.lineWidth = 2.5;
              ctx.lineCap = 'round';
              ctx.beginPath();
              // TL
              ctx.moveTo(mX, mY + arm);
              ctx.lineTo(mX, mY);
              ctx.lineTo(mX + arm, mY);
              // TR
              ctx.moveTo(rX - arm, mY);
              ctx.lineTo(rX, mY);
              ctx.lineTo(rX, mY + arm);
              // BR
              ctx.moveTo(rX, rY - arm);
              ctx.lineTo(rX, rY);
              ctx.lineTo(rX - arm, rY);
              // BL
              ctx.moveTo(mX + arm, rY);
              ctx.lineTo(mX, rY);
              ctx.lineTo(mX, rY - arm);
              ctx.stroke();
              ctx.restore();
            }
          }
        }
      }
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => {
      cancelled = true;
      cancelAnimationFrame(rafId);
    };
  }, [mode, cameraReady, autoCapture, captureFromVideo]);

  const activePage = pages[activeIndex] ?? null;

  // Render warped + filtered preview canvas in review mode (when not in corner crop editor)
  useEffect(() => {
    if (mode !== 'review' || cropEditing || !activePage) return;
    let cancelled = false;

    loadImgFromUrl(activePage.previewUrl)
      .then((img) => {
        if (cancelled || !previewCanvasRef.current) return;
        const warped = warpPerspectiveQuad(img, activePage.quad, activePage.rotation, 1050);
        const filtered = applyScannerFilter(warped, activePage.filter);
        const target = previewCanvasRef.current;
        target.width = filtered.width;
        target.height = filtered.height;
        const ctx = target.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, target.width, target.height);
          ctx.drawImage(filtered, 0, 0);
        }
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [mode, cropEditing, activePage]);

  // Load <img> for loupe zoom rendering when editing 4 corners
  useEffect(() => {
    if (!cropEditing || !activePage) {
      cropImgRef.current = null;
      return;
    }
    let cancelled = false;
    loadImgFromUrl(activePage.previewUrl)
      .then((img) => {
        if (!cancelled) cropImgRef.current = img;
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [cropEditing, activePage]);

  // Draw magnifying loupe when dragging any corner handle
  useEffect(() => {
    if (draggingCorner === null || !cropImgRef.current || !loupeCanvasRef.current) return;
    const pt = draftQuad[draggingCorner];
    const img = cropImgRef.current;
    const loupe = loupeCanvasRef.current;
    const ctx = loupe.getContext('2d');
    if (!ctx) return;

    const iw = img.naturalWidth || img.width;
    const ih = img.naturalHeight || img.height;
    const sampleRadius = Math.max(40, Math.min(iw, ih) * 0.09);
    const sx = pt.x * iw - sampleRadius;
    const sy = pt.y * ih - sampleRadius;

    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, loupe.width, loupe.height);
    ctx.drawImage(
      img,
      sx,
      sy,
      sampleRadius * 2,
      sampleRadius * 2,
      0,
      0,
      loupe.width,
      loupe.height
    );

    // Crosshair inside loupe
    const cx = loupe.width / 2;
    const cy = loupe.height / 2;
    ctx.strokeStyle = '#4285F4';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - 14, cy);
    ctx.lineTo(cx + 14, cy);
    ctx.moveTo(cx, cy - 14);
    ctx.lineTo(cx, cy + 14);
    ctx.stroke();
  }, [draggingCorner, draftQuad]);

  const handleImportPhotos = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setSaveError('');

    const added: ScannedPage[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const url = URL.createObjectURL(file);
      let detectedQuad: DocumentQuad = FULL_IMAGE_QUAD;
      try {
        const img = await loadImgFromUrl(url);
        detectedQuad = detectDocumentQuad(img) ?? FULL_IMAGE_QUAD;
      } catch {
        detectedQuad = FULL_IMAGE_QUAD;
      }
      added.push({
        id: `scan_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 6)}`,
        sourceBlob: file,
        previewUrl: url,
        quad: detectedQuad,
        rotation: 0,
        filter: 'clean',
      });
    }

    setPages((prev) => {
      if (retakingIndex !== null && added.length > 0) {
        const next = prev.map((p, idx) => {
          if (idx !== retakingIndex) return p;
          URL.revokeObjectURL(p.previewUrl);
          return added[0];
        });
        setActiveIndex(retakingIndex);
        setRetakingIndex(null);
        return next;
      }
      const next = [...prev, ...added];
      setActiveIndex(prev.length);
      return next;
    });
    setCropEditing(false);
    setMode('review');
    e.target.value = '';
  };

  const updateActivePage = (updater: (page: ScannedPage) => ScannedPage) => {
    setPages((prev) => prev.map((p, idx) => (idx === activeIndex ? updater(p) : p)));
  };

  const handleDeletePage = (idxToDelete: number) => {
    setPages((prev) => {
      const target = prev[idxToDelete];
      if (target) URL.revokeObjectURL(target.previewUrl);
      const next = prev.filter((_, i) => i !== idxToDelete);
      if (next.length === 0) {
        setActiveIndex(0);
        setCropEditing(false);
        setMode('camera');
      } else {
        setActiveIndex((cur) => Math.min(cur, next.length - 1));
      }
      return next;
    });
  };

  const handleMovePage = (dir: -1 | 1) => {
    const targetIdx = activeIndex + dir;
    if (targetIdx < 0 || targetIdx >= pages.length) return;
    setPages((prev) => {
      const copy = [...prev];
      const [moved] = copy.splice(activeIndex, 1);
      copy.splice(targetIdx, 0, moved);
      return copy;
    });
    setActiveIndex(targetIdx);
  };

  const handleCornerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (draggingCorner === null || !cropBoxRef.current) return;
    const rect = cropBoxRef.current.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    setDraftQuad((prev) => {
      const next: DocumentQuad = [...prev] as DocumentQuad;
      next[draggingCorner] = { x, y };
      return next;
    });
  };

  const handleSaveScannedPdf = async () => {
    if (pages.length === 0 || saving) return;
    setSaving(true);
    setSaveError('');
    try {
      const processedBlobs: Array<{ blob: Blob; mimeType: string }> = [];
      for (const page of pages) {
        const img = await loadImgFromUrl(page.previewUrl);
        const warped = warpPerspectiveQuad(img, page.quad, page.rotation, 1800);
        const filtered = applyScannerFilter(warped, page.filter);
        const blob = await new Promise<Blob>((resolve, reject) => {
          filtered.toBlob(
            (b) => (b ? resolve(b) : reject(new Error('Failed to encode scanned page'))),
            'image/jpeg',
            0.9
          );
        });
        processedBlobs.push({ blob, mimeType: 'image/jpeg' });
      }
      const pdfBlob = await createPdfFromImageBlobs(processedBlobs);
      await onSavePdf(pdfBlob, pages.length);
      stopCamera();
      onClose();
    } catch (err) {
      setSaveError(
        err instanceof Error ? err.message : 'Failed to create PDF. Please try again.'
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] bg-[#121214] text-white flex flex-col select-none">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-[#1B1B1F] border-b border-white/10 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            disabled={saving}
            onClick={() => {
              if (cropEditing) {
                setCropEditing(false);
                return;
              }
              stopCamera();
              onClose();
            }}
            className="p-2 rounded-xl hover:bg-white/10 disabled:opacity-40"
            aria-label="Close scanner"
          >
            {cropEditing ? <ArrowLeft className="w-5 h-5" /> : <X className="w-5 h-5" />}
          </button>
          <div className="min-w-0">
            <p className="text-sm font-bold truncate flex items-center gap-1.5">
              <ScanLine className="w-4 h-4 text-[#8AB4F8] shrink-0" />
              {cropEditing ? 'Adjust Corners' : docTitle}
            </p>
            <p className="text-[11px] text-white/65">
              {mode === 'camera'
                ? retakingIndex !== null
                  ? `Retaking page ${retakingIndex + 1}`
                  : `${pages.length} page${pages.length === 1 ? '' : 's'} scanned`
                : cropEditing
                  ? 'Drag the 4 blue corners onto document edges'
                  : `Page ${activeIndex + 1} of ${pages.length}`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {mode === 'camera' && (
            <>
              <button
                type="button"
                onClick={() => {
                  steadySinceRef.current = null;
                  setAutoCapture((v) => !v);
                }}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                  autoCapture
                    ? 'bg-[#1A73E8] text-white'
                    : 'bg-white/10 text-white/80 hover:bg-white/15'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                {autoCapture ? 'Auto' : 'Manual'}
              </button>
              {torchSupported && (
                <button
                  type="button"
                  onClick={toggleTorch}
                  className={`p-2 rounded-xl ${
                    torchOn ? 'bg-[#FDD663] text-black' : 'bg-white/10 hover:bg-white/15'
                  }`}
                  title="Flashlight"
                >
                  <Flashlight className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={() => setFacingMode((f) => (f === 'environment' ? 'user' : 'environment'))}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/15"
                title="Switch camera"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </>
          )}

          {mode === 'review' && !cropEditing && (
            <>
              <button
                type="button"
                disabled={saving}
                onClick={() => {
                  setRetakingIndex(null);
                  setMode('camera');
                }}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5"
              >
                <Camera className="w-4 h-4" />
                + Add
              </button>
              <button
                type="button"
                disabled={pages.length === 0 || saving}
                onClick={handleSaveScannedPdf}
                className="px-3.5 py-1.5 rounded-xl bg-[#1A73E8] hover:bg-[#1765CC] disabled:opacity-50 text-xs font-bold flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                {saving ? 'Saving…' : 'Done'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Content */}
      {mode === 'camera' ? (
        <div className="relative flex-1 flex items-center justify-center bg-black overflow-hidden">
          {cameraError ? (
            <div className="max-w-sm mx-auto p-6 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-[#1A73E8]/20 text-[#8AB4F8] flex items-center justify-center mx-auto">
                <Camera className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <p className="font-bold text-sm">Camera preview unavailable</p>
                <p className="text-xs text-white/70">{cameraError}</p>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={startCamera}
                  className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold"
                >
                  Retry Camera
                </button>
                <button
                  type="button"
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="px-4 py-2.5 rounded-xl bg-[#1A73E8] hover:bg-[#1765CC] text-xs font-bold flex items-center gap-1.5"
                >
                  <Camera className="w-4 h-4" />
                  Phone Camera
                </button>
                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center gap-1.5"
                >
                  <ImagePlus className="w-4 h-4" />
                  Gallery
                </button>
              </div>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                playsInline
                muted
                autoPlay
                className="w-full h-full object-contain"
              />
              {/* Live Blue Edge-Detection Overlay */}
              <canvas
                ref={overlayCanvasRef}
                className="pointer-events-none absolute inset-0 w-full h-full"
              />

              {/* Status Pill */}
              <div className="pointer-events-none absolute top-4 left-1/2 -translate-x-1/2 px-3.5 py-1.5 rounded-full bg-black/70 border border-white/15 text-xs font-medium text-white whitespace-nowrap">
                {scanStatus}
              </div>

              {/* Capture Flash */}
              {captureFlash && (
                <div className="pointer-events-none absolute inset-0 bg-white/75 transition-opacity" />
              )}
            </>
          )}
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden bg-[#141418]">
          {/* Preview OR 4-Corner Crop Editor */}
          <div className="relative flex-1 flex items-center justify-center p-4 overflow-hidden">
            {activePage && !cropEditing && (
              <canvas
                ref={previewCanvasRef}
                className="max-w-full max-h-full object-contain rounded-lg shadow-2xl bg-white"
              />
            )}

            {activePage && cropEditing && (
              <div
                ref={cropBoxRef}
                onPointerMove={handleCornerPointerMove}
                onPointerUp={() => setDraggingCorner(null)}
                onPointerCancel={() => setDraggingCorner(null)}
                className="relative inline-flex items-center justify-center max-w-full max-h-full touch-none"
              >
                <img
                  src={activePage.previewUrl}
                  alt="Adjust document corners"
                  draggable={false}
                  className="max-w-full max-h-[62vh] object-contain block rounded"
                />
                {/* Polygon lines SVG */}
                <svg
                  viewBox="0 0 100 100"
                  preserveAspectRatio="none"
                  className="absolute inset-0 w-full h-full pointer-events-none"
                >
                  <polygon
                    points={draftQuad.map((p) => `${p.x * 100},${p.y * 100}`).join(' ')}
                    fill="rgba(66, 133, 244, 0.14)"
                    stroke="#8AB4F8"
                    strokeWidth="0.7"
                  />
                </svg>
                {/* 4 Draggable Corner Handles */}
                {draftQuad.map((pt, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onPointerDown={(e) => {
                      e.preventDefault();
                      e.currentTarget.setPointerCapture(e.pointerId);
                      setDraggingCorner(idx);
                    }}
                    style={{
                      left: `${pt.x * 100}%`,
                      top: `${pt.y * 100}%`,
                    }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full border-2 border-white flex items-center justify-center shadow-lg transition-transform ${
                      draggingCorner === idx
                        ? 'bg-[#1A73E8] scale-125'
                        : 'bg-[#4285F4]/90 hover:scale-110'
                    }`}
                    aria-label={`Drag corner ${idx + 1}`}
                  >
                    <span className="w-2 h-2 rounded-full bg-white" />
                  </button>
                ))}
              </div>
            )}

            {/* Zoom Loupe while dragging a corner */}
            {cropEditing && draggingCorner !== null && (
              <div className="pointer-events-none absolute top-4 right-4 w-28 h-28 rounded-full border-2 border-[#8AB4F8] overflow-hidden shadow-2xl bg-black">
                <canvas ref={loupeCanvasRef} width={112} height={112} className="w-full h-full" />
              </div>
            )}
          </div>

          {/* Crop Editor Toolbar */}
          {cropEditing && activePage && (
            <div className="bg-[#1B1B1F] border-t border-white/10 px-4 py-3 flex flex-wrap items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const img = await loadImgFromUrl(activePage.previewUrl);
                      setDraftQuad(detectDocumentQuad(img) ?? FULL_QUAD);
                    } catch {
                      setDraftQuad(FULL_QUAD);
                    }
                  }}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#8AB4F8]" />
                  Auto-Detect
                </button>
                <button
                  type="button"
                  onClick={() => setDraftQuad(FULL_IMAGE_QUAD)}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Full Image
                </button>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCropEditing(false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-white/75 hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    updateActivePage((p) => ({ ...p, quad: draftQuad }));
                    setCropEditing(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-[#1A73E8] hover:bg-[#1765CC] text-xs font-bold flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Apply Crop
                </button>
              </div>
            </div>
          )}

          {/* Google Drive Review Action Strip */}
          {!cropEditing && activePage && (
            <div className="bg-[#1B1B1F] border-t border-white/10 px-4 py-2.5 space-y-2.5 shrink-0">
              {showFiltersBar && (
                <div className="flex items-center gap-2 overflow-x-auto pb-0.5">
                  {FILTER_OPTIONS.map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => updateActivePage((p) => ({ ...p, filter: f.id }))}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                        activePage.filter === f.id
                          ? 'bg-[#1A73E8] text-white'
                          : 'bg-white/10 text-white/80 hover:bg-white/15'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                  {pages.length > 1 && (
                    <button
                      type="button"
                      onClick={() => {
                        const chosen = activePage.filter;
                        setPages((prev) => prev.map((p) => ({ ...p, filter: chosen })));
                      }}
                      className="px-3 py-1.5 rounded-full text-[11px] font-semibold text-[#8AB4F8] bg-[#8AB4F8]/10 hover:bg-[#8AB4F8]/20 whitespace-nowrap ml-auto"
                    >
                      Apply to all
                    </button>
                  )}
                </div>
              )}

              <div className="flex items-center justify-between gap-2 overflow-x-auto">
                <button
                  type="button"
                  onClick={() => {
                    setDraftQuad(activePage.quad);
                    setCropEditing(true);
                  }}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                >
                  <Crop className="w-4 h-4 text-[#8AB4F8]" />
                  Crop
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateActivePage((p) => ({
                      ...p,
                      rotation: ((p.rotation + 90) % 360) as 0 | 90 | 180 | 270,
                    }))
                  }
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                >
                  <RotateCw className="w-4 h-4" />
                  Rotate
                </button>
                <button
                  type="button"
                  onClick={() => setShowFiltersBar((v) => !v)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap ${
                    showFiltersBar ? 'bg-white/20' : 'bg-white/10 hover:bg-white/15'
                  }`}
                >
                  <SlidersHorizontal className="w-4 h-4" />
                  Filters
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRetakingIndex(activeIndex);
                    setMode('camera');
                  }}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                >
                  <Camera className="w-4 h-4" />
                  Retake
                </button>
                {pages.length > 1 && (
                  <>
                    <button
                      type="button"
                      disabled={activeIndex === 0}
                      onClick={() => handleMovePage(-1)}
                      className="p-2 rounded-xl bg-white/10 hover:bg-white/15 disabled:opacity-30"
                      title="Move page left"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      disabled={activeIndex === pages.length - 1}
                      onClick={() => handleMovePage(1)}
                      className="p-2 rounded-xl bg-white/10 hover:bg-white/15 disabled:opacity-30"
                      title="Move page right"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => handleDeletePage(activeIndex)}
                  className="p-2 rounded-xl bg-[#B3261E]/30 hover:bg-[#B3261E]/50 text-[#FFB4AB]"
                  title="Delete page"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Bottom Thumbnail Strip & Camera Controls */}
      {!cropEditing && (
        <div className="bg-[#121216] border-t border-white/10 px-4 py-3 space-y-3 shrink-0">
          {saveError && (
            <p className="text-xs text-[#FFB4AB] text-center bg-[#B3261E]/25 border border-[#B3261E]/40 rounded-lg px-3 py-1.5">
              {saveError}
            </p>
          )}

          {pages.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {pages.map((p, idx) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setActiveIndex(idx);
                    setMode('review');
                  }}
                  className={`relative w-12 h-16 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                    mode === 'review' && activeIndex === idx
                      ? 'border-[#8AB4F8] scale-105'
                      : 'border-white/25 opacity-75 hover:opacity-100'
                  }`}
                >
                  <img
                    src={p.previewUrl}
                    alt={`Page ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-0.5 right-0.5 px-1 rounded bg-black/75 text-[9px] font-bold font-mono-nums">
                    {idx + 1}
                  </span>
                </button>
              ))}
            </div>
          )}

          {mode === 'camera' ? (
            <div className="flex items-center justify-between gap-2 max-w-lg mx-auto">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  className="px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5"
                  title="Scan photos from gallery"
                >
                  <ImagePlus className="w-4 h-4" />
                  Gallery
                </button>
                <button
                  type="button"
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5"
                  title="Capture with phone camera app"
                >
                  <Camera className="w-4 h-4" />
                  <span className="hidden sm:inline">Device Cam</span>
                </button>
              </div>

              <button
                type="button"
                disabled={!cameraReady || saving}
                onClick={() => captureFromVideo(smoothedQuadRef.current)}
                className="w-16 h-16 rounded-full bg-white text-[#1A73E8] flex items-center justify-center border-4 border-[#1A73E8] disabled:opacity-40 active:scale-95 transition-transform shadow-lg"
                aria-label="Capture document page"
              >
                <span className="w-11 h-11 rounded-full bg-white border-2 border-[#1A73E8]/30" />
              </button>

              <button
                type="button"
                disabled={pages.length === 0 || saving}
                onClick={() => setMode('review')}
                className="px-3.5 py-2.5 rounded-xl bg-[#1A73E8] hover:bg-[#1765CC] disabled:opacity-40 text-xs font-bold flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                Review ({pages.length})
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between gap-3 max-w-lg mx-auto">
              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center gap-1.5"
              >
                <ImagePlus className="w-4 h-4" />
                Add Photos
              </button>

              <button
                type="button"
                disabled={pages.length === 0 || saving}
                onClick={handleSaveScannedPdf}
                className="flex-1 py-3 px-5 rounded-xl bg-[#1A73E8] hover:bg-[#1765CC] disabled:opacity-50 text-sm font-bold flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                {saving
                  ? 'Creating PDF…'
                  : `Save PDF (${pages.length} ${pages.length === 1 ? 'page' : 'pages'})`}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Hidden Gallery & Native Camera Inputs */}
      <input
        ref={galleryInputRef}
        type="file"
        multiple
        accept="image/*"
        onChange={handleImportPhotos}
        className="hidden"
      />
      <input
        ref={nativeCameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleImportPhotos}
        className="hidden"
      />
    </div>
  );
};
